Use 'pip' to install the following modules for the build:

sphinxcontrib-fulltoc == 1.2.0
sphinx-bootstrap-theme == 0.6.0
sphinx_fontawesome

Uncomment example\\index in .\\index.rst to view example workshop
